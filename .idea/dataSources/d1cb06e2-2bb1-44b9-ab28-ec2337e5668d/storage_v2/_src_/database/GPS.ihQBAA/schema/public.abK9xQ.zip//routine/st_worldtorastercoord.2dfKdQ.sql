CREATE FUNCTION st_worldtorastercoord(rast raster, pt geometry, OUT columnx integer, OUT rowy integer)
  RETURNS record
IMMUTABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
		rx integer;
		ry integer;
	BEGIN
		IF st_geometrytype(pt) != 'ST_Point' THEN
			RAISE EXCEPTION 'Attempting to compute raster coordinate with a non-point geometry';
		END IF;
		IF ST_SRID(rast) != ST_SRID(pt) THEN
			RAISE EXCEPTION 'Raster and geometry do not have the same SRID';
		END IF;

		SELECT rc.columnx AS x, rc.rowy AS y INTO columnx, rowy FROM _st_worldtorastercoord($1, st_x(pt), st_y(pt)) AS rc;
		RETURN;
	END;

$$;

