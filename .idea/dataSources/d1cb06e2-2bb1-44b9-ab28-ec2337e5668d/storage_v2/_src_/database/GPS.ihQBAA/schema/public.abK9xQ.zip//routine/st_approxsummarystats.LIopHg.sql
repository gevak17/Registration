CREATE FUNCTION st_approxsummarystats(rast raster, nband integer, sample_percent double precision, OUT count bigint, OUT sum double precision, OUT mean double precision, OUT stddev double precision, OUT min double precision, OUT max double precision)
  RETURNS record
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT _st_summarystats($1, $2, TRUE, $3)
$$;

