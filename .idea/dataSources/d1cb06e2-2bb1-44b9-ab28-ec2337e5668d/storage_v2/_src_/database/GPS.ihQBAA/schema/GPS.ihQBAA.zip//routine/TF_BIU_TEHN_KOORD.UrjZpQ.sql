CREATE FUNCTION "TF_BIU_TEHN_KOORD"()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
pole_id text;--ID поля з яким проводяться зміни
sql_q text;--тимчасовий запит(змінна)
ev_nazva text;--назва евента
BEGIN 

	IF st_x(NEW."GPS_GEOM") = 0 OR 	st_y(NEW."GPS_GEOM") = 0 THEN
		RETURN NULL;
	END IF;

NEW."TEHN_ID"=(SELECT "TEHN_ID" FROM "GPS"."TRACKER" where "IMEI"=NEW."IMEI");

NEW."TEHN_VAL"=(SELECT "VAL" FROM "GPS"."TEHN" where "ID"=NEW."TEHN_ID");

NEW."DATE_ZMIN"=NOW();

if (select "ID" from "OPER"."DATE_ZMIN" where "VAL"='"GPS"."TEHN_KOORD"') is null then

    INSERT INTO "OPER"."DATE_ZMIN" ("VAL") 
			VALUES ('"GPS"."TEHN_KOORD"') ;--ADMIN

 END IF; 
 
UPDATE "OPER"."DATE_ZMIN"
   SET  "DATE_ZMIN"=NOW()
 WHERE  "VAL"='"GPS"."TEHN_KOORD"' or "VAL"='ALL';

 NEW."OPERATOR03_VAL"=(SELECT "VAL" FROM "OPER"."OPERATOR03"
   where "ID"=NEW."OPERATOR03_ID");

 pole_id :=NEW."ID";
 ev_nazva:=(select "VAL" || "ID" from  "OPER"."POVIDOM_ZMIN" where "TAB_NAZVA"='"GPS"."TEHN_KOORD"');
 
 if ev_nazva is null then
     INSERT INTO "OPER"."POVIDOM_ZMIN" ("VAL","TAB_NAZVA","OPERATOR03_ID")
			VALUES ('P','"GPS"."TEHN_KOORD"',10);-- RETURNING "VAL" || "ID"
     ev_nazva :=(select "VAL" || "ID" from  "OPER"."POVIDOM_ZMIN" where "TAB_NAZVA"='"GPS"."TEHN_KOORD"');
     
 END IF; 
 
 sql_q := 'NOTIFY ' || ev_nazva ||', ''' || pole_id ||''';';
EXECUTE sql_q; 




 
 
 return NEW;
 END;


$$;

