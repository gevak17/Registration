CREATE FUNCTION st_intersects(rast1 raster, rast2 raster)
  RETURNS boolean
IMMUTABLE
COST 1000
LANGUAGE SQL
AS $$
SELECT st_intersects($1, NULL::integer, $2, NULL::integer)
$$;

