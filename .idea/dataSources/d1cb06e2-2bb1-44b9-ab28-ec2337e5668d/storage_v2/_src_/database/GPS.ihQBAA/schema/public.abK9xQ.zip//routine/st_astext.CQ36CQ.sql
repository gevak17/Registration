CREATE FUNCTION st_astext(text)
  RETURNS text
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_AsText($1::geometry);
$$;

