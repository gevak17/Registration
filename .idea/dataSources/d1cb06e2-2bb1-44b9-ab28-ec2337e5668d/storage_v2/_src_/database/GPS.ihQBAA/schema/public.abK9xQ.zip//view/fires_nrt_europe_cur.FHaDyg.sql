CREATE VIEW fires_nrt_europe_cur AS
  SELECT fires_nrt_europe.latitude,
    fires_nrt_europe.longitude,
    fires_nrt_europe.bright_ti4,
    fires_nrt_europe.scan,
    fires_nrt_europe.track,
    fires_nrt_europe.acq_date,
    fires_nrt_europe.acq_time,
    fires_nrt_europe.satellite,
    fires_nrt_europe.confidence,
    fires_nrt_europe.version,
    fires_nrt_europe.bright_ti5,
    fires_nrt_europe.frp,
    fires_nrt_europe.daynight,
    fires_nrt_europe.geom,
    fires_nrt_europe.date_ins
   FROM fires_nrt_europe
  WHERE ((fires_nrt_europe.date_ins = (now())::date) AND ((fires_nrt_europe.confidence)::text <> 'nominal'::text));

