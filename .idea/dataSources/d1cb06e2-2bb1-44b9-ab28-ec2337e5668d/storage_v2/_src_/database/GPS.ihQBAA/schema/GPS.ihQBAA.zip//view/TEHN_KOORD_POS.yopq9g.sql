CREATE VIEW "TEHN_KOORD_POS" AS
  SELECT t1."IMEI",
    t1."TEHN_ID",
    t2."VAL" AS "TEHN_VAL",
    t1."DATE_GPS",
    date_trunc('sec'::text, t1."DATE_ZMIN") AS "DATE_ZMIN",
    t1."KUT",
    t1."L",
    t1."M",
    t1."I",
    t1."GPS_GEOM",
    t2."SORT"
   FROM ("GPS"."TEHN_KOORD" t1
     JOIN "GPS"."TEHN" t2 ON ((t1."TEHN_ID" = t2."ID")))
  WHERE (t1."ID" IN ( SELECT max("TEHN_KOORD"."ID") AS max
           FROM "GPS"."TEHN_KOORD"
          WHERE ("TEHN_KOORD"."TEHN_ID" IS NOT NULL)
          GROUP BY "TEHN_KOORD"."TEHN_ID"))
  ORDER BY t2."SORT";

