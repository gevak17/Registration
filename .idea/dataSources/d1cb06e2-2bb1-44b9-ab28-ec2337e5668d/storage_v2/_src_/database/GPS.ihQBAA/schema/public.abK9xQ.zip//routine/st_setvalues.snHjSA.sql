CREATE FUNCTION st_setvalues(rast raster, nband integer, x integer, y integer, newvalueset double precision[], nosetvalue double precision, keepnodata boolean DEFAULT false)
  RETURNS raster
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT _st_setvalues($1, $2, $3, $4, $5, NULL, TRUE, $6, $7)
$$;

