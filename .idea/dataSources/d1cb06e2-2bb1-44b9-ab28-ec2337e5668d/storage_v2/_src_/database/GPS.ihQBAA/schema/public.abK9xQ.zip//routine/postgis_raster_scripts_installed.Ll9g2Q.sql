CREATE FUNCTION postgis_raster_scripts_installed()
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2.1.2'::text || ' r' || 12389::text AS version
$$;

