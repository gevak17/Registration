CREATE VIEW fires_c6_europe_cur AS
  SELECT fires_c6_europe.latitude,
    fires_c6_europe.longitude,
    fires_c6_europe.bright_ti4,
    fires_c6_europe.scan,
    fires_c6_europe.track,
    fires_c6_europe.acq_date,
    fires_c6_europe.acq_time,
    fires_c6_europe.satellite,
    fires_c6_europe.confidence,
    fires_c6_europe.version,
    fires_c6_europe.bright_ti5,
    fires_c6_europe.frp,
    fires_c6_europe.daynight,
    fires_c6_europe.geom,
    fires_c6_europe.date_ins
   FROM fires_c6_europe
  WHERE ((fires_c6_europe.acq_date)::date = ((now() - '16:00:00'::interval))::date);

