CREATE FUNCTION "_st_within"(geom1 geometry, geom2 geometry)
  RETURNS boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT _ST_Contains($2,$1)
$$;

