CREATE FUNCTION st_rotatez(geometry, double precision)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_Rotate($1, $2)
$$;

