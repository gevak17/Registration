CREATE FUNCTION st_buffer(text, double precision)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_Buffer($1::geometry, $2);
$$;

