CREATE VIEW cz_pru_v AS
  SELECT cz_pru.id1,
    cz_pru.the_geom,
    cz_pru.id,
    cz_pru.id_doc,
    cz_pru.rayon,
    cz_pru.nazva,
    cz_pru.typ,
    cz_pru.klas,
    cz_pru.prymitka,
    cz_pru.vul_id,
    cz_pru.vul,
    cz_pru.nom,
    cz_pru.addr_id,
    cz_pru.tmp,
    cz_pru.visible
   FROM cz_pru
  WHERE (cz_pru.visible = true);

