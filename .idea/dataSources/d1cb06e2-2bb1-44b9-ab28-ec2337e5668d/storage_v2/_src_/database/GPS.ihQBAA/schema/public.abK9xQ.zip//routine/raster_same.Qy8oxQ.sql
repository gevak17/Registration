CREATE FUNCTION raster_same(raster, raster)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select $1::geometry ~= $2::geometry
$$;

