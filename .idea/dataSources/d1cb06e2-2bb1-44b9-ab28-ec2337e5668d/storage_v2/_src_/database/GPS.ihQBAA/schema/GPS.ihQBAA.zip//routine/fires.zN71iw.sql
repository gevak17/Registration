CREATE FUNCTION fires(dt timestamp without time zone, dt2 timestamp without time zone DEFAULT NULL::timestamp without time zone, OUT lat double precision, OUT lon double precision, OUT acq_date1 character varying, OUT confidence1 character varying, OUT daynight1 character varying)
  RETURNS SETOF record
LANGUAGE plpgsql
AS $$
BEGIN
 
 IF dt2 IS NULL THEN
 	dt2 = dt + INTERVAL '24  hour';
 END IF;

 RETURN QUERY 
	SELECT latitude,longitude, acq_date acq1, confidence,daynight FROM "public"."fires_c6_europe"
-- 	WHERE acq_date = '2016-03-14'	or acq_date = '2016-03-18';
	WHERE acq_date::TIMESTAMP = dt	or acq_date::TIMESTAMP = dt2;

	

 END;
$$;

