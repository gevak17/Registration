CREATE FUNCTION st_snaptogrid(geometry, double precision, double precision)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_SnapToGrid($1, 0, 0, $2, $3)
$$;

