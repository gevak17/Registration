CREATE VIEW "1Del_BUDYNKY" AS
  SELECT lviv_houses.gid,
    lviv_houses.workcond,
    lviv_houses.buildid,
    lviv_houses.streetid,
    lviv_houses.numb,
    lviv_houses.typebuild,
    lviv_houses.floor,
    lviv_houses.nomination,
    lviv_houses.shape_leng,
    lviv_houses.shape_area,
    lviv_houses.the_geom,
    lviv_houses.typebuild AS tmp,
        CASE
            WHEN (lviv_houses.floor > 0) THEN ((lviv_houses.floor)::numeric * 0.000015)
            ELSE 0.000015
        END AS tmp2
   FROM lviv_houses;

