CREATE VIEW lviv_street1 AS
  SELECT lviv_transportnet.streetid,
    st_union(lviv_transportnet.the_geom) AS the_geom,
    "RstrStreetName_di"."CityID",
    "RstrStreetName_di".title AS "Title",
    (lviv_transportnet.typ)::text AS typ
   FROM (lviv_transportnet
     JOIN vulici "RstrStreetName_di" ON ((((lviv_transportnet.streetid)::text = ("RstrStreetName_di".streetid)::text) AND (''::text = ''::text))))
  GROUP BY lviv_transportnet.streetid, "RstrStreetName_di"."CityID", "RstrStreetName_di".title, lviv_transportnet.typ;

