CREATE FUNCTION st_envelope(raster)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select st_envelope(st_convexhull($1))
$$;

