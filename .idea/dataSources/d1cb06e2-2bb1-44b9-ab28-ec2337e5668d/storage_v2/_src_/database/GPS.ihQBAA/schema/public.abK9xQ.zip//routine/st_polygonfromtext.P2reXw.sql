CREATE FUNCTION st_polygonfromtext(text)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_PolyFromText($1)
$$;

