CREATE FUNCTION st_multipolygonfromtext(text)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_MPolyFromText($1)
$$;

