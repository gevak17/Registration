CREATE VIEW tehn_koord_tmp AS
  SELECT "TEHN_KOORD"."ID",
    "TEHN_KOORD"."OPERATOR03_ID",
    "TEHN_KOORD"."OPERATOR03_VAL",
    "TEHN_KOORD"."IS_DEL",
    "TEHN_KOORD"."DATE_ZMIN",
    "TEHN_KOORD"."IMEI",
    "TEHN_KOORD"."TEHN_ID",
    "TEHN_KOORD"."TEHN_VAL",
    "TEHN_KOORD"."E",
    "TEHN_KOORD"."N",
    "TEHN_KOORD"."GPS_GEOM",
    "TEHN_KOORD"."DATE_GPS",
    "TEHN_KOORD"."KUT",
    "TEHN_KOORD"."L",
    "TEHN_KOORD"."M",
    "TEHN_KOORD"."I"
   FROM "GPS"."TEHN_KOORD"
  WHERE ((("TEHN_KOORD"."IMEI")::text = '354660042251960'::text) AND (date_trunc('day'::text, "TEHN_KOORD"."DATE_GPS") = '2014-02-01 00:00:00'::timestamp without time zone));

