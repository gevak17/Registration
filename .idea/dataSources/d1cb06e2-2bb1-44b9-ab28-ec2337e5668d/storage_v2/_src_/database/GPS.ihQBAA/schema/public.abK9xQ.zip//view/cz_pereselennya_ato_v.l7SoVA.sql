CREATE VIEW cz_pereselennya_ato_v AS
  SELECT p1.id,
    p1.the_geom,
    t2.ato[1] AS rayon,
    t2.ato[3] AS os_sim,
    t2.ato[4] AS os1,
    t2.ato[5] AS os2,
    t2.ato[6] AS os3,
    t2.ato[7] AS os4,
    ((((t2.ato[4])::integer + (t2.ato[5])::integer) + (t2.ato[6])::integer) + (t2.ato[7])::integer) AS os_sum
   FROM (( SELECT string_to_array(regexp_split_to_table((t1."ATO")::text, '\n'::text), '	'::text) AS ato
           FROM ( SELECT "PERESEL"."ID",
                    "PERESEL"."ATO",
                    "PERESEL"."KRIM",
                    "PERESEL"."DATA"
                   FROM "S112"."PERESEL"
                  ORDER BY "PERESEL"."ID" DESC
                 LIMIT 1) t1) t2
     RIGHT JOIN cz_pereselennya_ato p1 ON (((p1.rayon)::text = t2.ato[1])));

