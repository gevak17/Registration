CREATE FUNCTION postgis_scripts_build_date()
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2014-04-03 09:18:36'::text AS version
$$;

