CREATE FUNCTION st_polygon(geometry, integer)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_SetSRID(ST_MakePolygon($1), $2)

$$;

