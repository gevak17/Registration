CREATE FUNCTION st_asjpeg(rast raster, nband integer, quality integer)
  RETURNS bytea
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT st_asjpeg($1, ARRAY[$2], $3)
$$;

