CREATE FUNCTION st_intersection(text, text)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_Intersection($1::geometry, $2::geometry);
$$;

