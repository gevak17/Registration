CREATE VIEW lviv_gidrant_v AS
  SELECT g2.gid,
    g1."ID" AS id,
    st_setsrid(g2.the_geom, 4326) AS the_geom,
    (((g1."STREET_TXT")::text || ', '::text) || (g1."BUD")::text) AS adresa,
    g1."STREET_TXT" AS street_txt,
    g1."BUD" AS bud,
    g1."ZRAZOK" AS zrazok,
    g1."DIAMETR" AS diametr,
    g1."TYP" AS typ,
    COALESCE((ARRAY['Несправний'::text, 'Справний'::text])[(g1."SPRAVNYI" + (1)::numeric)], ''::text) AS spravnyi_txt,
    g1."SPRAVNYI" AS spravnyi,
    COALESCE((ARRAY['Нема'::text, 'Є'::text])[((g1."VKAZIVNYK")::integer + 1)], ''::text) AS vkazivnyk_txt,
    g1."VKAZIVNYK" AS vkazivnyk,
    g1."ADMINRAYON_ID" AS adminrayon,
    g1."PIDROZDIL_ID" AS pidrozdil,
    g1."PRYMITKA" AS prymitka
   FROM ("OPER2015"."GIDRANT_TEST_BLOCK" g1
     LEFT JOIN lviv_gidrant g2 ON ((g1."ID" = (g2.ora_id)::numeric)));

