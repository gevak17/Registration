CREATE FUNCTION st_rastertoworldcoord(rast raster, columnx integer, rowy integer, OUT longitude double precision, OUT latitude double precision)
  RETURNS record
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT longitude, latitude FROM _st_rastertoworldcoord($1, $2, $3)
$$;

