CREATE FUNCTION st_approxsummarystats(rastertable text, rastercolumn text, sample_percent double precision, OUT count bigint, OUT sum double precision, OUT mean double precision, OUT stddev double precision, OUT min double precision, OUT max double precision)
  RETURNS record
STABLE
STRICT
LANGUAGE SQL
AS $$
SELECT _st_summarystats($1, $2, 1, TRUE, $3)
$$;

