CREATE FUNCTION st_within(geom1 geometry, geom2 geometry)
  RETURNS boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $1 && $2 AND _ST_Contains($2,$1)
$$;

