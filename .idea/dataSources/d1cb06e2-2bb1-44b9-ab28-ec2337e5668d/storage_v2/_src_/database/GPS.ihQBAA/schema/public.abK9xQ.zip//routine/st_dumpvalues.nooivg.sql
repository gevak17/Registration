CREATE FUNCTION st_dumpvalues(rast raster, nband integer, exclude_nodata_value boolean DEFAULT true)
  RETURNS double precision[]
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT valarray FROM st_dumpvalues($1, ARRAY[$2]::integer[], $3)
$$;

