CREATE FUNCTION st_multilinestringfromtext(text, integer)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_MLineFromText($1, $2)
$$;

