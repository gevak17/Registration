CREATE VIEW lviv_street_20120411 AS
  SELECT lviv_transportnet.gid,
    lviv_transportnet.fnode_,
    lviv_transportnet.tnode_,
    lviv_transportnet.lpoly_,
    lviv_transportnet.rpoly_,
    lviv_transportnet.length,
    lviv_transportnet.temp_,
    lviv_transportnet.temp_id,
    lviv_transportnet.streetid,
    lviv_transportnet.category,
    lviv_transportnet.id,
    lviv_transportnet.len,
    lviv_transportnet.id_edge,
    lviv_transportnet.weight_l,
    lviv_transportnet.koef,
    lviv_transportnet.direct,
    lviv_transportnet.shape_leng,
    lviv_transportnet.shape_le_1,
    lviv_transportnet.the_geom,
    "RstrStreetName_di"."CityID",
    "RstrStreetName_di".streetid AS "StreetID",
    "RstrStreetName_di".title AS "Title",
    (lviv_transportnet.typ)::text AS type
   FROM (lviv_transportnet
     JOIN vulici "RstrStreetName_di" ON ((((lviv_transportnet.streetid)::text = ("RstrStreetName_di".streetid)::text) AND (''::text = ''::text))));

