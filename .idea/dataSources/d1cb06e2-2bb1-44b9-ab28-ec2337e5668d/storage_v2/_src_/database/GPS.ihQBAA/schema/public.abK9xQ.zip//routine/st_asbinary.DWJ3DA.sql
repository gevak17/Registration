CREATE FUNCTION st_asbinary(geography, text)
  RETURNS bytea
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_AsBinary($1::geometry, $2);
$$;

