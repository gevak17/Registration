CREATE FUNCTION "TF_BIU_TRAKER"()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
pole_id text;--ID поля з яким проводяться зміни
sql_q text;--тимчасовий запит(змінна)
ev_nazva text;--назва евента
BEGIN 
NEW."DATE_ZMIN"=NOW();

if (select "ID" from "OPER"."DATE_ZMIN" where "VAL"='"GPS"."TRAKER"') is null then

    INSERT INTO "OPER"."DATE_ZMIN" ("VAL") 
			VALUES ('"GPS"."TRAKER"') ;--ADMIN

 END IF; 
 
UPDATE "OPER"."DATE_ZMIN"
   SET  "DATE_ZMIN"=NOW()
 WHERE  "VAL"='"GPS"."TRAKER"' or "VAL"='ALL';

 NEW."OPERATOR03_VAL"=(SELECT "VAL" FROM "OPER"."OPERATOR03"
   where "ID"=NEW."OPERATOR03_ID");

 pole_id :=NEW."ID";
 ev_nazva:=(select "VAL" || "ID" from  "OPER"."POVIDOM_ZMIN" where "TAB_NAZVA"='"GPS"."TRAKER"');
 
 if ev_nazva is null then
     INSERT INTO "OPER"."POVIDOM_ZMIN" ("VAL","TAB_NAZVA","OPERATOR03_ID")
			VALUES ('P','"GPS"."TRAKER"',10);-- RETURNING "VAL" || "ID"
     ev_nazva :=(select "VAL" || "ID" from  "OPER"."POVIDOM_ZMIN" where "TAB_NAZVA"='"GPS"."TRAKER"');
     
 END IF; 
 
 sql_q := 'NOTIFY ' || ev_nazva ||', ''' || pole_id ||''';';
EXECUTE sql_q; 
 
 
 return NEW;
 END;


$$;

