CREATE FUNCTION tf_aiu_www()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
pole_id text;--ID поля з яким проводяться зміни
sql_q text;--тимчасовий запит(змінна)
ev_nazva text;

BEGIN 

 pole_id :=NEW.id;


IF (TG_OP = 'INSERT') then 
	 ev_nazva:='www_insert';	
	sql_q := 'NOTIFY ' || ev_nazva ||', ''' || pole_id ||''';';  
ELSE	 
	ev_nazva:='www_update';	
	sql_q := 'NOTIFY ' || ev_nazva ||', ''' || pole_id ||''';';  		
end if;


EXECUTE sql_q; 


   
 
 return NEW;
 END;


$$;

