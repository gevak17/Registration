CREATE FUNCTION tf_aiu_hora_temporary()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
pole_id text;--ID поля з яким проводяться зміни
sql_q text;--тимчасовий запит(змінна)
ev_nazva text;

BEGIN 

 pole_id :=NEW.id;


IF (TG_OP = 'INSERT') then 
	 ev_nazva:='hora_temporary_insert';	
	sql_q := 'NOTIFY ' || ev_nazva ||', ''' || pole_id ||''';';  
ELSE	 
	ev_nazva:='hora_temporary_update';	
	sql_q := 'NOTIFY ' || ev_nazva ||', ''' || pole_id ||''';';  		
end if;


EXECUTE sql_q; 


   
 
 return NEW;
 END;


$$;

