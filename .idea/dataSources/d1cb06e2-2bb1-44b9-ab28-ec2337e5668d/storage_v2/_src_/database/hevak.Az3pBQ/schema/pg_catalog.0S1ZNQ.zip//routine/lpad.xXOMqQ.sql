CREATE FUNCTION lpad(text, integer)
  RETURNS text
IMMUTABLE
STRICT
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.lpad($1, $2, ' ')
$$;

