CREATE FUNCTION polygon(circle)
  RETURNS polygon
IMMUTABLE
STRICT
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.polygon(12, $1)
$$;

