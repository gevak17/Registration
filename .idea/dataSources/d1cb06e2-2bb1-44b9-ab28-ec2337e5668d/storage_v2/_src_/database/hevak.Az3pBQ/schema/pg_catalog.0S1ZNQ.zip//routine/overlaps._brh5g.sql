CREATE FUNCTION "overlaps"(timestamp with time zone, timestamp with time zone, timestamp with time zone, interval)
  RETURNS boolean
STABLE
COST 1
LANGUAGE SQL
AS $$
select ($1, $2) overlaps ($3, ($3 + $4))
$$;

