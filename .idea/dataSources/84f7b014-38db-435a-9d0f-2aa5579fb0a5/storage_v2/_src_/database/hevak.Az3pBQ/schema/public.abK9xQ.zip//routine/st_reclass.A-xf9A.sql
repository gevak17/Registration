CREATE FUNCTION st_reclass(rast raster, reclassexpr text, pixeltype text)
  RETURNS raster
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT st_reclass($1, ROW(1, $2, $3, NULL))
$$;

