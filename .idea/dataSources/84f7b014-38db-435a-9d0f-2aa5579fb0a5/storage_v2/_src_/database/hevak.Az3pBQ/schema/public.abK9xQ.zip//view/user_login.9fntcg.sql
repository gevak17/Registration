CREATE VIEW user_login AS
  SELECT gidrant_login.id,
    gidrant_login.operator_id,
    gidrant_login.pidrozdil_id_2,
    gidrant_login.pog_id,
    gidrant_login.adminrayon_id,
    gidrant_login.id_del
   FROM oper.gidrant_login;

