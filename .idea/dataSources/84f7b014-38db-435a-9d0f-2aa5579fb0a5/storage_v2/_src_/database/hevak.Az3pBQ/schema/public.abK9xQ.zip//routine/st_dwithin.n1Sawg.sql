CREATE FUNCTION st_dwithin(geography, geography, double precision)
  RETURNS boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $1 && _ST_Expand($2,$3) AND $2 && _ST_Expand($1,$3) AND _ST_DWithin($1, $2, $3, true)
$$;

