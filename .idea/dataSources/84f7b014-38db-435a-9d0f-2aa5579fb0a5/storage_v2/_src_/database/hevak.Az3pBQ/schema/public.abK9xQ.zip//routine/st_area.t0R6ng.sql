CREATE FUNCTION st_area(text)
  RETURNS double precision
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_Area($1::geometry);
$$;

