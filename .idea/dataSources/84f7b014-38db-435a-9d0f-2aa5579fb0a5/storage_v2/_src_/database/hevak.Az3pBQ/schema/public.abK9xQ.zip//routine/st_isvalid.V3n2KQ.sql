CREATE FUNCTION st_isvalid(geometry, integer)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT (ST_isValidDetail($1, $2)).valid
$$;

