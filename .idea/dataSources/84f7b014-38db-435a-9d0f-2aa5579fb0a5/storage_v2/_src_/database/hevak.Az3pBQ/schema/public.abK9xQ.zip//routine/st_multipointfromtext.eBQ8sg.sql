CREATE FUNCTION st_multipointfromtext(text)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_MPointFromText($1)
$$;

