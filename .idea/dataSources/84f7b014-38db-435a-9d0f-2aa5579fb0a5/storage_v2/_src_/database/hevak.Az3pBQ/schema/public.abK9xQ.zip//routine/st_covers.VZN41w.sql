CREATE FUNCTION st_covers(geography, geography)
  RETURNS boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $1 && $2 AND _ST_Covers($1, $2)
$$;

