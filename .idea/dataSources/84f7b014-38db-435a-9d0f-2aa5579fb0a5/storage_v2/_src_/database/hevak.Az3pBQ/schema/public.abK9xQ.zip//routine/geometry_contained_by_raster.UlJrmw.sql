CREATE FUNCTION geometry_contained_by_raster(geometry, raster)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select $1 @ $2::geometry
$$;

