CREATE FUNCTION st_translate(geometry, double precision, double precision)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_Translate($1, $2, $3, 0)
$$;

