CREATE FUNCTION postgis_scripts_build_date()
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2015-07-11 13:49:24'::text AS version
$$;

