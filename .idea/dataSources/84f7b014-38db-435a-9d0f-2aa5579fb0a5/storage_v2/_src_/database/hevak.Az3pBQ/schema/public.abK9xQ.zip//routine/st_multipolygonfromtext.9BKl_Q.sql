CREATE FUNCTION st_multipolygonfromtext(text, integer)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_MPolyFromText($1, $2)
$$;

