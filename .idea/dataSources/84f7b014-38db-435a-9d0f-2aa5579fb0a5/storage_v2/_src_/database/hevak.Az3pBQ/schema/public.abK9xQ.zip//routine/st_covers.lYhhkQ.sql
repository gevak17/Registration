CREATE FUNCTION st_covers(rast1 raster, rast2 raster)
  RETURNS boolean
IMMUTABLE
COST 1000
LANGUAGE SQL
AS $$
SELECT st_covers($1, NULL::integer, $2, NULL::integer)
$$;

