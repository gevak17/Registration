CREATE FUNCTION st_bandisnodata(rast raster, forcechecking boolean)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT st_bandisnodata($1, 1, $2)
$$;

