CREATE FUNCTION st_worldtorastercoordx(rast raster, pt geometry)
  RETURNS integer
IMMUTABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
		xr integer;
	BEGIN
		IF ( st_geometrytype(pt) != 'ST_Point' ) THEN
			RAISE EXCEPTION 'Attempting to compute raster coordinate with a non-point geometry';
		END IF;
		IF ST_SRID(rast) != ST_SRID(pt) THEN
			RAISE EXCEPTION 'Raster and geometry do not have the same SRID';
		END IF;
		SELECT columnx INTO xr FROM _st_worldtorastercoord($1, st_x(pt), st_y(pt));
		RETURN xr;
	END;

$$;

