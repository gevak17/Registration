CREATE FUNCTION geometry_raster_contain(geometry, raster)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select $1 ~ $2::geometry
$$;

