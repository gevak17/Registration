CREATE FUNCTION raster_contained(raster, raster)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select $1::geometry @ $2::geometry
$$;

