CREATE FUNCTION st_quantile(rast raster, nband integer, quantiles double precision[], OUT quantile double precision, OUT value double precision)
  RETURNS SETOF record
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT _st_quantile($1, $2, TRUE, 1, $3)
$$;

