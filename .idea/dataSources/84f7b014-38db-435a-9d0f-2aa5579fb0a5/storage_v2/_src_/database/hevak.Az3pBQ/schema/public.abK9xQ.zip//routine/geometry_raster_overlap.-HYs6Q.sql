CREATE FUNCTION geometry_raster_overlap(geometry, raster)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select $1 && $2::geometry
$$;

