CREATE FUNCTION box3d(raster)
  RETURNS box3d
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select box3d(st_convexhull($1))
$$;

