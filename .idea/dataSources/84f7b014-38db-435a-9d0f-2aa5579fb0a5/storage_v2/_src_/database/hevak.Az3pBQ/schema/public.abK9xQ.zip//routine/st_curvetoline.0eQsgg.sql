CREATE FUNCTION st_curvetoline(geometry)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_CurveToLine($1, 32)
$$;

