CREATE VIEW user_v AS
  SELECT operator_01.id,
    34 AS age,
    'ROLE_USER' AS authority,
    'sodu2016@lv.mns.gov.ua' AS email,
    operator_01.val AS name,
    operator_01.password,
    operator_01.val AS surname,
    operator_01.val AS username,
    operator_01.pidrozdil_id
   FROM operator_01;

