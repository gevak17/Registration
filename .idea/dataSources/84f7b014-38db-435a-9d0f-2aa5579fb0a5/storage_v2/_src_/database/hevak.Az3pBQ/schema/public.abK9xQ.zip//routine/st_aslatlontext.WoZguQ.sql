CREATE FUNCTION st_aslatlontext(geometry)
  RETURNS text
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_AsLatLonText($1, '')
$$;

