CREATE FUNCTION st_distance_sphere(geom1 geometry, geom2 geometry)
  RETURNS double precision
IMMUTABLE
STRICT
COST 300
LANGUAGE SQL
AS $$
select st_distance(geography($1),geography($2),false)

$$;

