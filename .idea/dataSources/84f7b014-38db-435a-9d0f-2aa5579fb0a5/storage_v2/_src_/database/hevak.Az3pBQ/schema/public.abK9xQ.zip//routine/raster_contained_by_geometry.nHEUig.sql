CREATE FUNCTION raster_contained_by_geometry(raster, geometry)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select $1::geometry @ $2
$$;

