CREATE FUNCTION st_locate_along_measure(geometry, double precision)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_locate_between_measures($1, $2, $2)
$$;

