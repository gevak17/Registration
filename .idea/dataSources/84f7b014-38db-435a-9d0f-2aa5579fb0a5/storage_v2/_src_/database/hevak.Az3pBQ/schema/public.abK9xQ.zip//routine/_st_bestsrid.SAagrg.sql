CREATE FUNCTION "_st_bestsrid"(geography)
  RETURNS integer
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT _ST_BestSRID($1,$1)
$$;

