CREATE FUNCTION st_polygonfromtext(text, integer)
  RETURNS geometry
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT ST_PolyFromText($1, $2)
$$;

