CREATE FUNCTION raster_geometry_contain(raster, geometry)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
select $1::geometry ~ $2
$$;

