CREATE FUNCTION postgis_raster_scripts_installed()
  RETURNS text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2.1.8'::text || ' r' || 13780::text AS version
$$;

