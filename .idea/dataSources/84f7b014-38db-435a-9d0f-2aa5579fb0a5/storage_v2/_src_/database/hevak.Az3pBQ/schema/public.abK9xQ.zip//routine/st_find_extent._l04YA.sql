CREATE FUNCTION st_find_extent(text, text, text)
  RETURNS box2d
IMMUTABLE
STRICT
LANGUAGE plpgsql
AS $$
DECLARE
	schemaname alias for $1;
	tablename alias for $2;
	columnname alias for $3;
	myrec RECORD;

BEGIN
	FOR myrec IN EXECUTE 'SELECT ST_Extent("' || columnname || '") As extent FROM "' || schemaname || '"."' || tablename || '"' LOOP
		return myrec.extent;
	END LOOP;
END;
$$;

