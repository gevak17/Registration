CREATE FUNCTION st_intersects(text, text)
  RETURNS boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT ST_Intersects($1::geometry, $2::geometry);
$$;

